package com.example.ilauncher

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class App(val label: String, val pkg: String, val icon: ImageBitmap, val cat: Int)

private val DOCK = listOf(
    "com.samsung.android.dialer", "com.samsung.android.messaging",
    "com.sec.android.app.sbrowser", "com.sec.android.app.camera"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { Launcher() }
    }
}

fun loadApps(ctx: Context): List<App> {
    val pm = ctx.packageManager
    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(q, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map {
            App(
                it.loadLabel(pm).toString(), it.activityInfo.packageName,
                it.loadIcon(pm).toBitmap(160, 160).asImageBitmap(),
                it.activityInfo.applicationInfo.category
            )
        }
        .sortedBy { it.label.lowercase() }
}

fun catName(c: Int) = when (c) {
    ApplicationInfo.CATEGORY_SOCIAL -> "Social"
    ApplicationInfo.CATEGORY_GAME -> "Games"
    ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO -> "Entertainment"
    ApplicationInfo.CATEGORY_IMAGE -> "Photo & Video"
    ApplicationInfo.CATEGORY_NEWS -> "Reading"
    ApplicationInfo.CATEGORY_MAPS -> "Travel"
    ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productivity"
    else -> "Other"
}

fun Modifier.glass(r: Int = 24) =
    clip(RoundedCornerShape(r.dp)).background(Color.White.copy(alpha = 0.22f))

@Composable
fun Launcher() {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf(emptyList<App>()) }
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { loadApps(ctx) } }
    var cc by remember { mutableStateOf(false) }

    val dock = DOCK.mapNotNull { p -> apps.find { it.pkg == p } }
    val pages = (apps - dock.toSet()).chunked(20)
    val pager = rememberPagerState { pages.size + 1 }

    Box(Modifier.fillMaxSize().systemBarsPadding()) {
        Column(Modifier.fillMaxSize()) {
            HorizontalPager(pager, Modifier.weight(1f)) { p ->
                if (p < pages.size) HomePage(pages[p]) else Library(apps)
            }
            Row(Modifier.fillMaxWidth().padding(6.dp), horizontalArrangement = Arrangement.Center) {
                repeat(pager.pageCount) {
                    Box(
                        Modifier.padding(3.dp).size(7.dp).clip(CircleShape)
                            .background(Color.White.copy(if (it == pager.currentPage) 1f else 0.4f))
                    )
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(12.dp).glass(32).padding(12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) { dock.forEach { AppIcon(it, showLabel = false) } }
        }
        // Swipe down from the top edge -> Control Center
        Box(
            Modifier.fillMaxWidth().height(40.dp).pointerInput(Unit) {
                var d = 0f
                detectVerticalDragGestures(
                    onDragStart = { d = 0f },
                    onDragEnd = { if (d > 80f) cc = true }
                ) { _, y -> d += y }
            }
        )
        if (cc) ControlCenter { cc = false }
    }
}

@Composable
fun HomePage(list: List<App>) {
    LazyVerticalGrid(
        GridCells.Fixed(4), Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) { items(list) { AppIcon(it) } }
}

@Composable
fun AppIcon(app: App, showLabel: Boolean = true, size: Int = 60) {
    val ctx = LocalContext.current
    Column(
        Modifier.clickable { ctx.packageManager.getLaunchIntentForPackage(app.pkg)?.let { ctx.startActivity(it) } },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            app.icon, app.label,
            Modifier.size(size.dp).clip(RoundedCornerShape((size * 0.225f).dp))
        )
        if (showLabel) Text(
            app.label, color = Color.White, fontSize = 11.sp, maxLines = 1,
            overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp).width(68.dp)
        )
    }
}

@Composable
fun Library(apps: List<App>) {
    val groups = apps.groupBy { catName(it.cat) }.toList()
    LazyVerticalGrid(
        GridCells.Fixed(2), Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(groups) { (name, list) ->
            Column {
                Column(Modifier.fillMaxWidth().glass().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    list.take(4).chunked(2).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            row.forEach { AppIcon(it, showLabel = false, size = 48) }
                        }
                    }
                }
                Text(name, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(4.dp))
            }
        }
    }
}

@Composable
fun ControlCenter(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val cm = remember { ctx.getSystemService(CameraManager::class.java) }
    var torch by remember { mutableStateOf(false) }
    fun open(action: String) = ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(0.55f)).clickable(
            interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClose
        ),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(Modifier.padding(16.dp).fillMaxWidth().glass(32).padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Tile("📶", "Wi-Fi", false) { open(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) }
                Tile("🔵", "Bluetooth", false) { open(Settings.ACTION_BLUETOOTH_SETTINGS) }
                Tile("✈️", "Авиа", false) { open(Settings.ACTION_AIRPLANE_MODE_SETTINGS) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Tile("🔊", "Звук", false) { open(Settings.ACTION_SOUND_SETTINGS) }
                Tile("☀️", "Яркость", false) { open(Settings.ACTION_DISPLAY_SETTINGS) }
                Tile("🔦", "Фонарь", torch) {
                    torch = !torch
                    runCatching { cm.setTorchMode(cm.cameraIdList[0], torch) }
                }
            }
        }
    }
}

@Composable
fun Tile(icon: String, label: String, on: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick)) {
        Box(
            Modifier.size(64.dp).clip(CircleShape)
                .background(if (on) Color.White else Color.White.copy(0.25f)),
            contentAlignment = Alignment.Center
        ) { Text(icon, fontSize = 26.sp) }
        Text(label, color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    }
}
